using Library.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Library.Infrastructure.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Book> Books { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Book>(entity =>
            {
                entity.ToTable("Books");

                entity.HasKey(b => b.Id);

                entity.Property(b => b.Title)
                      .IsRequired()
                      .HasMaxLength(200);

                entity.Property(b => b.Author)
                      .IsRequired()
                      .HasMaxLength(150);

                entity.Property(b => b.Publisher)
                      .IsRequired()
                      .HasMaxLength(150);

                entity.Property(b => b.Category)
                      .IsRequired()
                      .HasMaxLength(100);

                entity.Property(b => b.Isbn)
                      .HasMaxLength(20);

                entity.Property(b => b.CreatedAt)
                      .IsRequired();

                entity.Property(b => b.UpdatedAt)
                      .IsRequired(false);
            });
        }
    }
}
