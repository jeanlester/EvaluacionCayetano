namespace Library.Domain.Entities
{
    public class Book
    {
        public int Id { get; set; }                 // PK
        public string Title { get; set; }           // Título
        public string Author { get; set; }          // Autor
        public int PublicationYear { get; set; }    // Año de publicación
        public string Publisher { get; set; }       // Editorial
        public int Pages { get; set; }              // Cantidad de páginas
        public string Category { get; set; }        // Categoría (novela, técnico, etc.)

        // Campos adicionales
        public string Isbn { get; set; }            // ISBN
        public DateTime CreatedAt { get; set; }     // Fecha de registro
        public DateTime? UpdatedAt { get; set; }    // Fecha de actualización
    }
}
