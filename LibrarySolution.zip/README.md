# Library API (.NET 8)

API REST para gestión de Libros implementada con ASP.NET Core .NET 8, siguiendo buenas prácticas de arquitectura en capas (Domain, Application, Infrastructure, Api).

## Tecnologías

- .NET 8
- ASP.NET Core Web API
- Entity Framework Core 8 (SQL Server)
- Swagger / OpenAPI
- xUnit (para pruebas unitarias, opcional)
- Opcional: Amazon.Lambda.AspNetCoreServer (para despliegue en AWS Lambda)

## Requisitos previos

- .NET SDK 8 instalado
- SQL Server local o remoto
- Visual Studio 2022 (o VS Code)

## Configuración de base de datos

1. Crear la base de datos ejecutando el script:

```sql
CREATE DATABASE LibraryDb;
GO
USE LibraryDb;
GO
CREATE TABLE Books (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(200) NOT NULL,
    Author NVARCHAR(150) NOT NULL,
    PublicationYear INT NOT NULL,
    Publisher NVARCHAR(150) NOT NULL,
    Pages INT NOT NULL,
    Category NVARCHAR(100) NOT NULL,
    Isbn NVARCHAR(20) NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    UpdatedAt DATETIME2 NULL
);
GO
```

2. Actualizar la cadena de conexión en `Library.Api/appsettings.json`:

```json
"ConnectionStrings": {
  "DefaultConnection": "Server=localhost;Database=LibraryDb;Trusted_Connection=True;TrustServerCertificate=True;"
}
```

## Ejecutar la solución localmente

Desde Visual Studio:

1. Establecer `Library.Api` como proyecto de inicio.
2. Ejecutar con **F5**.
3. Abrir Swagger en `https://localhost:<puerto>/swagger`.

Desde CLI:

```bash
cd Library.Api
dotnet run
```

## Endpoints disponibles

Todos los endpoints están bajo el prefijo `api/Books`.

- `GET /api/Books`  
  Retorna la lista de libros.

- `GET /api/Books/{id}`  
  Retorna un libro por Id.

- `POST /api/Books`  
  Crea un nuevo libro.  
  Ejemplo de body:

```json
{
  "title": "Clean Code",
  "author": "Robert C. Martin",
  "publicationYear": 2008,
  "publisher": "Prentice Hall",
  "pages": 464,
  "category": "Programming",
  "isbn": "9780132350884"
}
```

- `PUT /api/Books/{id}`  
  Actualiza un libro existente.

- `DELETE /api/Books/{id}`  
  Elimina un libro existente.

## Postman Collection

Se incluye el archivo `LibraryApi.postman_collection.json` en la raíz del repo.  
Importarlo en Postman para probar los endpoints.

## Manejo de errores y validaciones

- Validaciones de entrada mediante `DataAnnotations` en los DTOs.
- Manejo de errores global con un endpoint `/error` registrado en `Program.cs`.
- Respuestas estándar HTTP (`400`, `404`, `201`, `204`, `500`).

## AWS Lambda (Deseable)

La solución puede adaptarse para ejecutarse en AWS Lambda usando el paquete `Amazon.Lambda.AspNetCoreServer`.  
Pasos generales:

1. Agregar los paquetes `Amazon.Lambda.AspNetCoreServer` y `Amazon.Lambda.Tools`.
2. Crear un entry point (`LambdaEntryPoint`) que herede de `APIGatewayHttpApiV2ProxyFunction`.
3. Publicar usando `dotnet lambda deploy-serverless` (según la configuración de `aws-lambda-tools-defaults.json`).
