using Library.Application.DTOs.Books;
using Library.Application.Interfaces;
using Library.Domain.Entities;

namespace Library.Application.Services
{
    public class BookService : IBookService
    {
        private readonly IBookRepository _bookRepository;

        public BookService(IBookRepository bookRepository)
        {
            _bookRepository = bookRepository;
        }

        public async Task<IEnumerable<BookResponseDto>> GetAllAsync()
        {
            var books = await _bookRepository.GetAllAsync();

            return books.Select(b => new BookResponseDto
            {
                Id = b.Id,
                Title = b.Title,
                Author = b.Author,
                PublicationYear = b.PublicationYear,
                Publisher = b.Publisher,
                Pages = b.Pages,
                Category = b.Category,
                Isbn = b.Isbn,
                CreatedAt = b.CreatedAt,
                UpdatedAt = b.UpdatedAt
            });
        }

        public async Task<BookResponseDto> GetByIdAsync(int id)
        {
            var book = await _bookRepository.GetByIdAsync(id);
            if (book == null) return null;

            return new BookResponseDto
            {
                Id = book.Id,
                Title = book.Title,
                Author = book.Author,
                PublicationYear = book.PublicationYear,
                Publisher = book.Publisher,
                Pages = book.Pages,
                Category = book.Category,
                Isbn = book.Isbn,
                CreatedAt = book.CreatedAt,
                UpdatedAt = book.UpdatedAt
            };
        }

        public async Task<BookResponseDto> CreateAsync(BookCreateDto dto)
        {
            var book = new Book
            {
                Title = dto.Title,
                Author = dto.Author,
                PublicationYear = dto.PublicationYear,
                Publisher = dto.Publisher,
                Pages = dto.Pages,
                Category = dto.Category,
                Isbn = dto.Isbn,
                CreatedAt = DateTime.UtcNow
            };

            var created = await _bookRepository.AddAsync(book);

            return await GetByIdAsync(created.Id);
        }

        public async Task<BookResponseDto> UpdateAsync(int id, BookUpdateDto dto)
        {
            var exists = await _bookRepository.GetByIdAsync(id);
            if (exists == null)
                return null;

            exists.Title = dto.Title;
            exists.Author = dto.Author;
            exists.PublicationYear = dto.PublicationYear;
            exists.Publisher = dto.Publisher;
            exists.Pages = dto.Pages;
            exists.Category = dto.Category;
            exists.Isbn = dto.Isbn;
            exists.UpdatedAt = DateTime.UtcNow;

            await _bookRepository.UpdateAsync(exists);

            return await GetByIdAsync(id);
        }

        public async Task DeleteAsync(int id)
        {
            var book = await _bookRepository.GetByIdAsync(id);
            if (book == null) return;

            await _bookRepository.DeleteAsync(book);
        }
    }
}
