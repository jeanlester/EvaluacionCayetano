using System.ComponentModel.DataAnnotations;

namespace Library.Application.DTOs.Books
{
    public class BookCreateDto
    {
        [Required]
        [MaxLength(200)]
        public string Title { get; set; }

        [Required]
        [MaxLength(150)]
        public string Author { get; set; }

        [Range(1, 2100)]
        public int PublicationYear { get; set; }

        [Required]
        [MaxLength(150)]
        public string Publisher { get; set; }

        [Range(1, int.MaxValue)]
        public int Pages { get; set; }

        [Required]
        [MaxLength(100)]
        public string Category { get; set; }

        [MaxLength(20)]
        public string Isbn { get; set; }
    }
}
