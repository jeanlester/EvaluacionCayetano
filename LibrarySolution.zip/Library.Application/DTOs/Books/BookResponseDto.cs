namespace Library.Application.DTOs.Books
{
    public class BookResponseDto
    {
        public int Id { get; set; }                 
        public string Title { get; set; }           
        public string Author { get; set; }          
        public int PublicationYear { get; set; }    
        public string Publisher { get; set; }       
        public int Pages { get; set; }              
        public string Category { get; set; }        
        public string Isbn { get; set; }            
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
    }
}
