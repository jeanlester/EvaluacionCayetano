using Library.Application.DTOs.Books;

namespace Library.Application.Interfaces
{
    public interface IBookService
    {
        Task<IEnumerable<BookResponseDto>> GetAllAsync();
        Task<BookResponseDto> GetByIdAsync(int id);
        Task<BookResponseDto> CreateAsync(BookCreateDto dto);
        Task<BookResponseDto> UpdateAsync(int id, BookUpdateDto dto);
        Task DeleteAsync(int id);
    }
}
